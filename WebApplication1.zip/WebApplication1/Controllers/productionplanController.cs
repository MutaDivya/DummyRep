using Microsoft.AspNetCore.Mvc;

using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class productionplanController : ControllerBase
    {
        private decimal TempLoad;
        public List<powerProductionTemp> powerProductionDetailsTemplst = new List<powerProductionTemp>();
        public powerProductionTemp powerProductionDetailsTemp;

        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<productionplanController> _logger;

        public productionplanController(ILogger<productionplanController> logger)
        {
            _logger = logger;
        }

        //[HttpGet(Name = "GetWeatherForecast")]
        //public IEnumerable<WeatherForecast> Get()
        //{
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = Random.Shared.Next(-20, 55),
        //        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}

        [HttpPost]
        public JsonResult productionplan(LoadDetailsVM loadDetailsViewModel)
        {
            TempLoad = Convert.ToDecimal(loadDetailsViewModel.load);

            for (int i = 0; i < loadDetailsViewModel.powerplants.Count; i++)
            {
                if (TempLoad >= loadDetailsViewModel.powerplants[i].pmin && loadDetailsViewModel.powerplants[i].type.Equals("windturbine") )
                {
                    loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = Convert.ToDecimal(loadDetailsViewModel.fuels.windPercentage * loadDetailsViewModel.powerplants[i].pmax * 0.01);

                    if (TempLoad >= loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType)
                    {
                        powerProductionDetailsTemp = new powerProductionTemp();
                        TempLoad = Convert.ToDecimal((TempLoad - loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType));
                        powerProductionDetailsTemp.TempP = loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType;
                        powerProductionDetailsTemp.TempName = loadDetailsViewModel.powerplants[i].name;
                        powerProductionDetailsTemplst.Add(powerProductionDetailsTemp);
                    }

                }
            }

            for (int i = 0; i < loadDetailsViewModel.powerplants.Count; i++)
            {
                if (loadDetailsViewModel.powerplants[i].type.Equals("gasfired"))
                {
                    powerProductionDetailsTemp = new powerProductionTemp();
                    if (TempLoad >= loadDetailsViewModel.powerplants[i].pmin && TempLoad < loadDetailsViewModel.powerplants[i].pmax)
                    {
                        loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = TempLoad;
                        TempLoad = Convert.ToDecimal(TempLoad - loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType);
                    }
                    else if (TempLoad >= loadDetailsViewModel.powerplants[i].pmin)
                    {
                        loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = loadDetailsViewModel.powerplants[i].pmax;
                        TempLoad = Convert.ToDecimal((TempLoad - loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType));
                    }
                    else
                    { loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = 0; }
                    powerProductionDetailsTemp.TempP = loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType;
                    powerProductionDetailsTemp.TempName = loadDetailsViewModel.powerplants[i].name;
                    powerProductionDetailsTemplst.Add(powerProductionDetailsTemp);
                }

            }

            for (int i = 0; i < loadDetailsViewModel.powerplants.Count; i++)
            {
                if (loadDetailsViewModel.powerplants[i].type.Equals("turbojet"))
                {
                    powerProductionDetailsTemp = new powerProductionTemp();
                    if (TempLoad >= loadDetailsViewModel.powerplants[i].pmin && TempLoad < loadDetailsViewModel.powerplants[i].pmax)
                    {
                        loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = TempLoad;                       
                        TempLoad = Convert.ToDecimal(TempLoad - loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType);
                    }
                    else if (TempLoad >= loadDetailsViewModel.powerplants[i].pmin)
                    {
                        loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = loadDetailsViewModel.powerplants[i].pmax;
                        TempLoad = Convert.ToDecimal(TempLoad - loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType);
                    }
                    else
                    { loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType = 0; }
                    powerProductionDetailsTemp.TempP = loadDetailsViewModel.powerplants[i].TotalPowerProducedByThisType;
                    powerProductionDetailsTemp.TempName = loadDetailsViewModel.powerplants[i].name;
                    powerProductionDetailsTemplst.Add(powerProductionDetailsTemp);

                }
               
            }

            //throw new UnauthorizedAccessException();

            return new JsonResult(powerProductionDetailsTemplst);
        }
    }
}